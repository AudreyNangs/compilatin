import static org.junit.jupiter.api.Assertions.*;

class AnalyseLexicaleTest {

    @org.junit.jupiter.api.Test
    void ERREUR() {
    }

    @org.junit.jupiter.api.Test
    void ajouter() {
    }

    @org.junit.jupiter.api.Test
    void lireCar() {
    }

    @org.junit.jupiter.api.Test
    void sauterSeparateurs() {
    }

    @org.junit.jupiter.api.Test
    void sauterCommentaire() {
    }

    @org.junit.jupiter.api.Test
    void recoEntier() {
    }

    @org.junit.jupiter.api.Test
    void recoChaine() {
    }

    @org.junit.jupiter.api.Test
    void recoIdentOuMotReserve() {
    }

    @org.junit.jupiter.api.Test
    void recoSymb() {
    }

    @org.junit.jupiter.api.Test
    void ANALEX() {
    }

    @org.junit.jupiter.api.Test
    void initialiser() {
    }

    @org.junit.jupiter.api.Test
    void terminer() {
    }
}