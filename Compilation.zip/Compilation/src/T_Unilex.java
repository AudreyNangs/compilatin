public enum T_Unilex {  motcle, ident, ent, ch, virg, ptvirg, point, deuxpts, parouv, parfer, inf, sup, eg, plus, moins, mutl, divi, infe,
    supe, diff, aff
}

